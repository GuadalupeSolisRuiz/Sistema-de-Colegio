<?php
session_start();
include 'includes/db.php';

if (isset($_POST['btn_cita'])) {
    $id_user = $_SESSION['usuario_id'];
    $motivo  = mysqli_real_escape_string($conn, $_POST['motivo']); 
    
    $fecha   = $_POST['fecha'];
    $hora    = $_POST['hora'];

    // Asegúrate de que el nombre de la tabla coincida con la que creaste (citas o citas_plantel)
    $query = "INSERT INTO citas_plantel (id_usuario, motivo, fecha_cita, hora_cita) VALUES ('$id_user', '$motivo', '$fecha', '$hora')";

    if (mysqli_query($conn, $query)) {
        header("Location: dashboard.php?seccion=cita_plantel&status=ok");
    } else {
        echo "Error al registrar la cita: " . mysqli_error($conn);
    }
}
?>