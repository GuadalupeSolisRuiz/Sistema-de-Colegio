<?php
// 1. Iniciamos la sesión para poder guardar los datos del usuario
session_start();

// 2. Incluimos la conexión a la base de datos
include 'includes/db.php'; 

if(!isset($_SESSION['usuario_id'])) { 
    header("Location: login.php"); 
    exit();
}

// CONSULTA: Obtenemos datos frescos del usuario y su nombre de rol
$id_user = $_SESSION['usuario_id'];
$query_user = "SELECT u.*, r.nombre_rol 
               FROM usuarios u 
               INNER JOIN roles r ON u.rol = r.id_rol 
               WHERE u.id = '$id_user'";
$res_user = mysqli_query($conn, $query_user);
$datos_usuario = mysqli_fetch_assoc($res_user);

$rol = $datos_usuario['rol']; 
$nombre_rol_texto = $datos_usuario['nombre_rol']; // Para usarlo en la UI

// Control de navegación
$seccion = isset($_GET['seccion']) ? $_GET['seccion'] : 'inicio';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema Escolar | Dashboard</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --purple-primary: #6f42c1; --purple-dark: #4b2394; }
        body { background-color: #f8f9fa; }
        .sidebar { width: 280px; height: 100vh; background: var(--purple-dark); color: white; position: fixed; }
        .main-content { margin-left: 280px; padding: 20px; }
        .nav-link { color: rgba(255,255,255,0.8); margin: 5px 0; }
        .nav-link:hover, .nav-link.active { background: var(--purple-primary); color: white; border-radius: 8px; }
        .navbar-custom { background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 15px; }
        .text-purple { color: var(--purple-primary); }
        .btn-purple-outline { border: 1px solid var(--purple-primary); color: var(--purple-primary); }
        .btn-purple-outline:hover { background: var(--purple-primary); color: white; }
    </style>
</head>
<body>

<div class="d-flex">
    <div class="sidebar d-flex flex-column p-3">
        <div class="d-flex align-items-center mb-4 text-white text-decoration-none">
            <i class="bi bi-mortarboard-fill fs-2 me-2"></i>
            <span class="fs-4 fw-bold">Nombre Escuela</span>
        </div>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
            <li><a href="dashboard.php?seccion=inicio" class="nav-link <?php echo ($seccion=='inicio')?'active':''; ?>"><i class="bi bi-house-door me-2"></i> Inicio</a></li>
            
            <?php if($rol == 3): // ALUMNOS ?>
                <li><a href="dashboard.php?seccion=historial" class="nav-link <?php echo ($seccion=='historial')?'active':''; ?>"><i class="bi bi-journal-check me-2"></i> Historial Académico</a></li>
                <li><a href="dashboard.php?seccion=cita_plantel" class="nav-link <?php echo ($seccion=='cita_plantel')?'active':''; ?>"><i class="bi bi-calendar-plus me-2"></i> Solicitar Cita</a></li>
            <?php endif; ?>

            <?php if($rol == 2 || $rol == 1): // MAESTROS Y SISTEMAS ?>
                <li><a href="dashboard.php?seccion=captura" class="nav-link <?php echo ($seccion=='captura')?'active':''; ?>"><i class="bi bi-pencil-square me-2"></i> Captura de Notas</a></li>
                <li><a href="dashboard.php?seccion=gestion_citas" class="nav-link <?php echo ($seccion=='gestion_citas')?'active':''; ?>"><i class="bi bi-calendar-check me-2"></i> Gestión de Citas</a></li>
            <?php endif; ?>

            <?php if($rol == 1): // SOLO SISTEMAS ?>
                <li><a href="dashboard.php?seccion=gestion_usuarios" class="nav-link <?php echo ($seccion=='gestion_usuarios')?'active':''; ?>"><i class="bi bi-gear me-2"></i> Gestión de Usuarios</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="main-content w-100">
        <nav class="navbar navbar-custom d-flex justify-content-between mb-4">
            <span class="badge bg-purple-light text-purple p-2">
                Sesión: <span class="fw-bold"><?php echo $nombre_rol_texto; ?></span>
            </span>
            
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" id="userMenu" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=<?php echo $_SESSION['nombre']; ?>&background=6f42c1&color=fff" alt="" class="rounded-circle me-2" width="32">
                    <strong><?php echo $_SESSION['nombre']; ?></strong>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                    <li><a class="dropdown-item text-danger" href="includes/cerrar.php"><i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión</a></li>
                </ul>
            </div>
        </nav>

        <div class="container-fluid">
            <?php
            switch ($seccion) {
                case 'gestion_usuarios':
                    if($rol == 1) include 'vistas/usuarios.php';
                    break;
                case 'captura':
                    if($rol == 1 || $rol == 2) include 'vistas/captura_notas.php';
                    break;
                case 'cita_plantel':
                    include 'vistas/citas.php';
                    break;
                case 'gestion_citas':
                    if($rol == 1 || $rol == 2) include 'vistas/gestion_citas.php';
                    break;
                case 'historial':
                    include 'vistas/inicio_alumno.php';
                    break;
                default:
                    include 'vistas/inicio_alumno.php';
                    break;
            }
            ?>
        </div>
    </div>
</div>

<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>