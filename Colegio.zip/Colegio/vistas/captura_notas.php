<div class="card border-0 shadow-sm p-4">
    <h5 class="fw-bold text-purple"><i class="bi bi-pencil-fill me-2"></i> Capturar Calificaciones</h5>
    <form action="includes/procesar_notas.php" method="POST" class="row g-3 mt-2">
        <div class="col-md-4">
            <label class="form-label">Seleccionar Alumno</label>
            <select name="id_alumno" class="form-select" required>
                <option value="">Seleccione...</option>
                <?php
                $res_alumnos = mysqli_query($conn, "SELECT id, nombre FROM usuarios WHERE rol = 3");
                while($al = mysqli_fetch_assoc($res_alumnos)){
                    echo "<option value='".$al['id']."'>".$al['nombre']."</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">Materia</label>
            <input type="text" name="materia" class="form-control" placeholder="Ej: Bases de Datos" required>
        </div>
        <div class="col-md-2">
            <label class="form-label">Parcial 1</label>
            <input type="number" step="0.1" name="p1" class="form-control" min="0" max="10" required>
        </div>
        <div class="col-md-2">
            <label class="form-label">Parcial 2</label>
            <input type="number" step="0.1" name="p2" class="form-control" min="0" max="10" required>
        </div>
        <div class="col-md-1 d-flex align-items-end">
            <button type="submit" name="btn_subir_nota" class="btn btn-purple w-100 text-white" style="background:var(--purple-primary)">
                <i class="bi bi-save"></i>
            </button>
        </div>
    </form>
</div>

<div class="card border-0 shadow-sm p-4 mt-4">
    <h5 class="fw-bold text-muted mb-3">Últimos registros</h5>
    <table class="table table-sm">
        <thead>
            <tr><th>Alumno</th><th>Materia</th><th>Promedio</th></tr>
        </thead>
        <tbody>
            <?php
            $sql_h = "SELECT c.*, u.nombre FROM calificaciones c INNER JOIN usuarios u ON c.id_alumno = u.id ORDER BY c.id DESC LIMIT 5";
            $res_h = mysqli_query($conn, $sql_h);
            while($h = mysqli_fetch_assoc($res_h)):
                $p = ($h['parcial1'] + $h['parcial2']) / 2;
            ?>
            <tr>
                <td><?php echo $h['nombre']; ?></td>
                <td><?php echo $h['materia']; ?></td>
                <td><span class="badge bg-light text-dark"><?php echo number_format($p, 1); ?></span></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>