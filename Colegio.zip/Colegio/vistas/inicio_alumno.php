<?php
// CRUCIAL: Heredamos la conexión del dashboard
global $conn;

// Obtenemos el ID del alumno desde la sesión
$id_logeado = $_SESSION['usuario_id'];

// Consultamos las calificaciones
$query_calif = "SELECT * FROM calificaciones WHERE id_alumno = '$id_logeado' ORDER BY materia ASC";
$res_calif = mysqli_query($conn, $query_calif);
?>

<h2 class="mb-4 text-secondary">Bienvenido, <?php echo $_SESSION['nombre']; ?></h2>

<div class="row">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm p-4">
            <h5 class="fw-bold text-purple mb-3">
                <i class="bi bi-journal-bookmark-fill me-2"></i> Historial Académico
            </h5>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Materia</th>
                            <th class="text-center">P1</th>
                            <th class="text-center">P2</th>
                            <th class="text-center">Promedio</th>
                            <th class="text-center">Estatus</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($res_calif) > 0):
                            while($reg = mysqli_fetch_assoc($res_calif)):
                                $prom = ($reg['parcial1'] + $reg['parcial2']) / 2;
                                
                                // Colores dinámicos según el promedio
                                $badge_color = ($prom >= 6) ? 'bg-success' : 'bg-danger';
                                $status_text = ($prom >= 6) ? 'Aprobado' : 'Reprobado';
                        ?>
                        <tr>
                            <td class="fw-bold"><?php echo $reg['materia']; ?></td>
                            <td class="text-center"><?php echo number_format($reg['parcial1'], 1); ?></td>
                            <td class="text-center"><?php echo number_format($reg['parcial2'], 1); ?></td>
                            <td class="text-center">
                                <span class="badge <?php echo $badge_color; ?> px-3">
                                    <?php echo number_format($prom, 1); ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <small class="text-muted fw-bold"><?php echo $status_text; ?></small>
                            </td>
                        </tr>
                        <?php 
                            endwhile; 
                        else:
                        ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">
                                <i class="bi bi-info-circle me-1"></i> Aún no tienes calificaciones registradas.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 text-white mb-3" style="background: var(--purple-primary);">
            <h6 class="fw-bold"><i class="bi bi-megaphone-fill me-2"></i> Avisos Recientes</h6>
            <hr class="border-light">
            <p class="mb-0 small">No olvides realizar tu evaluación docente antes del viernes.</p>
        </div>
        
        <div class="card border-0 shadow-sm p-4 bg-white">
    <h6 class="text-secondary fw-bold">Información de Usuario</h6>
    <p class="small mb-1">
        <strong>Correo:</strong> 
        <?php echo isset($_SESSION['correo']) ? $_SESSION['correo'] : 'No disponible'; ?>
    </p>
    <p class="small mb-0">
        <strong>Matrícula:</strong> #<?php echo $_SESSION['usuario_id']; ?>
    </p>
</div>
    </div>
</div>