<?php
global $conn;

// Consulta con JOIN para traer el nombre del alumno
$query = "SELECT c.*, u.nombre as alumno_nombre 
          FROM citas_plantel c 
          JOIN usuarios u ON c.id = u.id 
          ORDER BY c.fecha_cita DESC";

$res_citas = mysqli_query($conn, $query);

// ESTO TE DIRÁ EL ERROR REAL SI LA CONSULTA FALLA
if (!$res_citas) {
    die("<div class='alert alert-danger'>Error en la consulta: " . mysqli_error($conn) . "</div>");
}
?>

<div class="card border-0 shadow-sm p-4">
    <h4 class="fw-bold text-purple mb-4">
        <i class="bi bi-calendar-check-fill me-2"></i> Control de Citas al Plantel
    </h4>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Alumno</th>
                    <th>Motivo</th>
                    <th>Fecha/Hora</th>
                    <th>Estatus Actual</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($reg = mysqli_fetch_assoc($res_citas)): ?>
                <tr>
                    <td><strong><?php echo $reg['alumno_nombre']; ?></strong></td>
                    <td><?php echo $reg['motivo']; ?></td>
                    <td><?php echo date('d/m/Y H:i', strtotime($reg['fecha_cita'])); ?></td>
                    <td>
                        <?php 
                        $badge_class = 'bg-warning';
                        if($reg['estatus'] == 'Aprobada') $badge_class = 'bg-info';
                        if($reg['estatus'] == 'Completada') $badge_class = 'bg-success';
                        if($reg['estatus'] == 'Cancelada') $badge_class = 'bg-danger';
                        ?>
                        <span class="badge <?php echo $badge_class; ?> rounded-pill">
                            <?php echo $reg['estatus']; ?>
                        </span>
                    </td>
                    <td>
                        <form action="includes/actualizar_cita.php" method="POST" class="d-flex gap-2">
                            <input type="hidden" name="id_cita" value="<?php echo $reg['id']; ?>">
                            <select name="nuevo_estatus" class="form-select form-select-sm" style="width: 130px;">
                                <option value="Pendiente" <?php if($reg['estatus'] == 'Pendiente') echo 'selected'; ?>>Pendiente</option>
                                <option value="Aprobada" <?php if($reg['estatus'] == 'Aprobada') echo 'selected'; ?>>Aprobada</option>
                                <option value="Completada" <?php if($reg['estatus'] == 'Completada') echo 'selected'; ?>>Completada</option>
                                <option value="Cancelada" <?php if($reg['estatus'] == 'Cancelada') echo 'selected'; ?>>Cancelada</option>
                            </select>
                            <button type="submit" name="btn_actualizar_status" class="btn btn-sm btn-purple-outline">
                                <i class="bi bi-check2-circle"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>