<div class="modal fade" id="modalUsuario" tabindex="-1">
    <div class="modal-dialog">
        <form action="includes/procesar_usuario.php" method="POST" class="modal-content border-0 shadow">
            <div class="modal-header text-white" style="background: var(--purple-dark);">
                <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Registrar Nuevo Miembro</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Nombre Completo</label>
                    <input type="text" name="nombre" class="form-control" required placeholder="Ej. Juan Pérez">
                </div>
                <div class="mb-3">
                    <label class="form-label">Correo Institucional</label>
                    <input type="email" name="correo" class="form-control" required placeholder="usuario@escuela.edu">
                </div>
                <div class="mb-3">
                    <label class="form-label">Contraseña</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Asignar Rol</label>
                    <select name="rol" class="form-select">
                        <option value="3">Alumno</option>
                        <option value="2">Maestro</option>
                        <option value="1">Sistemas</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" name="btn_guardar" class="btn btn-success w-100">Guardar Usuario</button>
            </div>
        </form>
    </div>
</div>