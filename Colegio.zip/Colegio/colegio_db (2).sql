-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-03-2026 a las 02:13:35
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `colegio_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificaciones`
--

CREATE TABLE `calificaciones` (
  `id` int(11) NOT NULL,
  `id_alumno` int(11) DEFAULT NULL,
  `materia` varchar(100) DEFAULT NULL,
  `parcial1` decimal(4,2) DEFAULT NULL,
  `parcial2` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `calificaciones`
--

INSERT INTO `calificaciones` (`id`, `id_alumno`, `materia`, `parcial1`, `parcial2`) VALUES
(1, 1, 'Programación Web', 9.50, 10.00),
(2, 1, 'Bases de Datos', 8.00, 9.00),
(3, 1, 'Redes', 9.87, 7.25),
(4, 1, 'Redes 2', 8.00, 6.00),
(5, 3, 'Redes 2', 7.00, 7.00),
(6, 3, 'Redacción', 4.00, 8.00),
(7, 1, 'Redes 2', 8.00, 7.00),
(8, 3, 'Redes 2', 7.00, 7.00),
(9, 17, 'Redes 2', 7.00, 7.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas_plantel`
--

CREATE TABLE `citas_plantel` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `motivo` varchar(100) NOT NULL,
  `fecha_cita` date NOT NULL,
  `hora_cita` time NOT NULL,
  `estatus` varchar(20) DEFAULT 'Pendiente',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `citas_plantel`
--

INSERT INTO `citas_plantel` (`id`, `id_usuario`, `motivo`, `fecha_cita`, `hora_cita`, `estatus`, `fecha_creacion`) VALUES
(1, 2, 'Trámites Administrativos', '2026-03-21', '18:00:00', 'Completada', '2026-03-14 00:00:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `nombre_rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre_rol`) VALUES
(1, 'Admin'),
(2, 'Maestro'),
(3, 'Alumno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `rol` int(11) DEFAULT NULL COMMENT '1:Admin, 2:Maestro, 3:Alumno',
  `foto_perfil` varchar(255) DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `password`, `rol`, `foto_perfil`) VALUES
(1, 'Juan Pérez', 'alumno@colegio.com', '7894', 3, 'default.png'),
(2, 'Tu Nombre', 'admin@admin.com', '12345', 1, 'default.png'),
(3, 'Luis Angel', 'Angel@colegio.com', '$2y$10$ZUDApyJ9Rhbv81mwmTr3uuoO46eco1FMu/QXTGnRkQFwg.7xAVify', 3, 'default.png'),
(4, 'Luis Angel', 'Angel11@colegio.com', '12345', 1, 'default.png'),
(5, 'Lupe', 'lupe@ejemplo.com', '$2y$10$EpheNh39g9GJjzot/LdTs.vBCKBpa9fKs7GNx9CftEN7CE9D.TbVm', 1, 'default.png'),
(6, 'Luis', 'luis@ejemplo.com', '1212', 3, 'default.png'),
(7, 'Luis', 'aaa@gmail.com', '147', 2, 'default.png'),
(8, 'Paula', 'paula@ejem.com', '258', 2, 'default.png'),
(17, '1', 'q@q.com', '1111', 3, 'default.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_alumno` (`id_alumno`);

--
-- Indices de la tabla `citas_plantel`
--
ALTER TABLE `citas_plantel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuario_cita` (`id_usuario`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD KEY `fk_usuario_rol` (`rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `citas_plantel`
--
ALTER TABLE `citas_plantel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `calificaciones_ibfk_1` FOREIGN KEY (`id_alumno`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `citas_plantel`
--
ALTER TABLE `citas_plantel`
  ADD CONSTRAINT `fk_usuario_cita` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`rol`) REFERENCES `roles` (`id_rol`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
