<?php
session_start();
include 'db.php'; // Al estar en la misma carpeta, solo pones el nombre

if (!isset($_SESSION['rol']) || $_SESSION['rol'] == 3) {
    header("Location: ../dashboard.php");
    exit();
}

if (isset($_POST['btn_subir_nota'])) {
    $id_alumno = $_POST['id_alumno'];
    $materia   = mysqli_real_escape_string($conn, $_POST['materia']);
    $p1        = $_POST['p1'];
    $p2        = $_POST['p2'];

    $sql = "INSERT INTO calificaciones (id_alumno, materia, parcial1, parcial2) 
            VALUES ('$id_alumno', '$materia', '$p1', '$p2')";

    if (mysqli_query($conn, $sql)) {
        // Salimos de 'includes' y volvemos al dashboard con aviso de éxito
        header("Location: ../dashboard.php?seccion=captura&status=success");
    } else {
        header("Location: ../dashboard.php?seccion=captura&error=db");
    }
    exit();
}
?>