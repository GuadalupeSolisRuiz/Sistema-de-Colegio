<?php
// 1. Reanudamos la sesión actual para poder manipularla
session_start();

// 2. Limpiamos todas las variables de sesión ($_SESSION['nombre'], etc.)
session_unset();

// 3. Destruimos la sesión en el servidor
session_destroy();

// 4. Redirigimos al usuario al login con un mensaje de "sesión cerrada"
header("Location:../login.php");
exit();
?>