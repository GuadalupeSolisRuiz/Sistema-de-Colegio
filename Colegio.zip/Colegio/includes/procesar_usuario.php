<?php
session_start();
include 'db.php';

if (isset($_POST['btn_guardar'])) {
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $correo = mysqli_real_escape_string($conn, $_POST['correo']);
    $pass   = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encriptamos por seguridad
    $rol    = $_POST['rol'];

    // 1. Verificar si el correo ya existe
    $check = mysqli_query($conn, "SELECT * FROM usuarios WHERE correo = '$correo'");
    
    // --- DENTRO DE procesar_usuario.php ---

if (mysqli_num_rows($check) > 0) {
    // REVISA ESTA LÍNEA: No debe decir vistas/dashboard... ni nada parecido
    header("Location:../dashboard.php?seccion=gestion_usuarios&error=duplicado");
    exit();
} else {
    // 1. Aquí escribimos la consulta real. 
    // Asegúrate de que los nombres (nombre, correo, password, rol) sean IGUALES a tu phpMyAdmin
    $query = "INSERT INTO usuarios (nombre, correo, password, rol) 
              VALUES ('$nombre', '$correo', '$pass', '$rol')";
    
    if (mysqli_query($conn, $query)) {
        // ÉXITO: Salimos de la carpeta includes y volvemos al dashboard
        header("Location: ../dashboard.php?seccion=gestion_usuarios&status=success");
    } else {
        // ERROR: Si algo falla en el SQL, mandamos el error para mostrar la alerta roja
        header("Location: ../dashboard.php?seccion=gestion_usuarios&error=db");
    }
    exit();
}
}
?>